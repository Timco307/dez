# readme!!!
this repository has reached its end, after like idk 1 and a half years of constant updates, the community has slowed down and new exploits are months apart. if you need contact, email me at stanleygriffin99@gmail.com (do not question the email.) the repository will be permanently archived and my journey will continue another year or something. (its also draining dealing with issues, asking for updates, and overall maintaining repositories alone.) if you want to join the team just make a business inquiry with your skills and maybe we could actually do something.

# how to "un~~en~~roll" (complicated)
If you're intrested in unrolling your cb, (which is dangerous and sometimes ~~illegal~~, see [unroll.md](https://github.com/zek-c/securly-kill-v111/unroll.md)

# state of the repo

lately as you can tell, there has been little to no pushes. the exploit community is running dry and there is no new content. theres no longer much to update. this repository "may" be archived in the coming months.

## NEW EXPLOIT (by [dragon731012](https://github.com/dragon731012)), [cauDNS!](https://github.com/dragon731012/caudns)
<br>
usage instructions: 
<hr>
    Head to <a href="https://caudns.vercel.app">Dragon's Vercel</a> or my <a href="https://zekurly.netlify.app/cauDNS.html">mirror</a>
    <hr>
        head to chrome://network#state, and expand your most commonly used wifi networks then copy the contents
        <hr> 
            Paste contents into the input field, and generate the file, then import it at the bottom of chrome://network#general
            <hr>
that should be it, you've successfully blocked multiple extensions

# as of ChromeOS V119, all of these below methods are patched. use [caub](https://caub.glitch.me/old) to stop updates or [downgrade](https://chrome100.dev) to keep these exploits working
<hr>

# before you use insecurly
<br>
bypassi has found yet another awesome exploit,
both links are <a href="https://skiovox.com">here</a> and <a href="https://github.com/bypassiwastaken/skiovox-helper">here</a>. this exploit allows you to go into a browser in kiosk mode and install ANY extension you want and do anything you want. please consider this before insecurly, as it always works and is working on every version (you must have kiosk apps)


## PATCHED AS OF V116- (unless you can run bookmarklets)
NEW EXPLOIT FOUND BY BYPASSI!
[bypassis new exploit](https://github.com/zek-c/Securly-Kill-V111/blob/main/bypassi.html)
you can run this exploit at my website, [here](https://zekurly.netlify.app/bypassi), or bypassis website [here](https://insecurly.bypassi.com) or codepen [here](https://codepen.io/zek-c/pen/JjwzvjZ)
<hr>
You're probably here to disable "secure"ly. This collection of exploits can bypass or disable securly.

<hr>

step 1. get the bookmarklet [here](https://github.com/zek-c/extension-v111-kill/blob/main/bookmarklet.js) or go to [My Website](https://zekurly.netlify.app) for easy drag and drop to bookmarks bar

<hr>

step 2. Put the JavaScript in a bookmarklet.

<hr>

step 3. go to [Securly](https://securly.com)

<hr>

step 4. click the bookmark and an "OFF" button will appear. Click this and it will turn on the Securly killer (Which should last forever, no need to re enable) and Click it again to turn it off.

<hr>

This will hard disable securly. It won't disable the extension, but corrupt the cookies. it will remove the blocking string it adds to the source code of websites it blocks. it sets the cookies to expire in a date far in the future (Will most likely last longer than securly exists) so you clearly won't ever need to enable this again unless you clear your cookies
<hr>
