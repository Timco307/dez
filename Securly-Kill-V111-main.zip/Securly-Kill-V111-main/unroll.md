# cryptosmite
## read the whole thing before making irresponsible decisions
yeah, thats it<br>
cryptosmite is new, and also really dumb (for the fact you cant do certain things) its basically a weakened sh1mmer. <Br>
if ur here you wanted to do it anyways... so here you go <br> 
the easy route: <br>
if you dont like taking the hard route, go to [darkn's host](dl.osu.bio/sh1mmer/prebuilt/legacy) (spoiler alert: if it wasnt modified in march it probably doesnt have csmite in it, so look at the date before you try. if it wasnt modified in march, you have to build it, see below for that)
<br>
download your respective board, you can see your board version in chrome://version, or if thats blocked you can see your board by looking at the bottom of your chromebook and looking it up on https://cros.tech <br>
download chrome recovery utility, or some other USB writer. <br>
plug in your 8gb MINIMUM (16 is maximim for most) to your PERSONAL computer and write the sh1m bin file to USB using the etch utility you chose. <br>
now ur ready <br>
press 'esc+refresh+power' at the same time, then press 'crtl+d' at the same time once youre on recovery screen <br>
it should say 'DEVMODE BLOCKED' or something  like that, thats okay (or if its not blocked thats even cooler) <br>
press 'esc+refresh+power' again WITHOUT returning to secure mode <br>
then plug in the written sh1m and it will boot<br>
once on the sh1m screen (if it said no valid image, you did something wrong or your kernver is too high. im not gonna explain that to u guys bc u probably wont understand no offense. oh also i shoulda mentioned this earlier but you should be on version 118 or below. just downlaod a recovery and write it to usb using the writer tool you chose, and then downgrade, no devmode needed, unless you are on a too high kernver; then you cant do this exploit.) <br>
press S and type 'Info-58-immense!NickName_Arabia-710'. its the decryption code. make sure to get it EXACTLY right with capitals and symbols. or it wont work. <br>
then just say YESSSSS on the screen and you should be chillaxing<br>
#after csmite
<br>
after youre on the screen yk, press esc power refresh again, then ctrl d again. it should ACTUALLY let you go into devmode now. then after entering devmode, on setup screen enable debug featuers. then cool, you got an unrolled chromebook
<br>
## dont actually do this, i was just joking a lil (wink wink though) i would NEVER recommend this (winkwink again)

<br>
how to build one, for you sad ppl who dont have one :( <br>
you need a personal computer with linux or windows subsystem for linux.
<br> ok heres the guides im not explaining this:https://docs.google.com/presentation/d/1MciRMbDEb3RJomH2gYW9C5qRVjS4P92o2s4QepoCSgY/edit#slide=id.g29ad28bf314_0_10, https://github.com/fwsmasher/cryptosmite, 
