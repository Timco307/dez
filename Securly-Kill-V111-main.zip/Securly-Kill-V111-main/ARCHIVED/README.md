<hr>
this is all of my past versions of this exploit. therefore, un needed. except if you wanna look at em so here u go
<hr>
